from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from datetime import datetime

from ..database import Base


class ThreatLog(Base):
    __tablename__ = "threat_logs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    threat_type = Column(String(120), nullable=False)
    severity = Column(String(50), nullable=False)
    details = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from datetime import datetime

from ..database import Base


class ScanHistory(Base):
    __tablename__ = "scan_history"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    target = Column(String(255), nullable=False)
    result = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

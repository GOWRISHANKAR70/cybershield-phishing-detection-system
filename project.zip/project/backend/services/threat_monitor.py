from datetime import datetime
from ..models.threat_log import ThreatLog


def generate_sample_threats(user_id: int):
    now = datetime.utcnow().isoformat()
    return [
        {
            "threat_type": "Suspicious Login Attempt",
            "severity": "Medium",
            "details": "A login was attempted from an unknown IP address.",
            "timestamp": now,
        },
        {
            "threat_type": "Potential Data Exfiltration",
            "severity": "High",
            "details": "Large outbound traffic detected outside business hours.",
            "timestamp": now,
        },
    ]


def log_threat(db, user_id: int, threat_type: str, severity: str, details: str):
    threat = ThreatLog(user_id=user_id, threat_type=threat_type, severity=severity, details=details)
    db.add(threat)
    db.commit()
    db.refresh(threat)
    return threat

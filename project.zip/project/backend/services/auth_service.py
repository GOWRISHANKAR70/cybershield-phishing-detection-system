import hashlib
from sqlalchemy.orm import Session

from ..models.user import User


def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def register_user(db: Session, username: str, email: str, password: str):
    existing_user = db.query(User).filter((User.username == username) | (User.email == email)).first()
    if existing_user:
        return None

    user = User(username=username, email=email, password=hash_password(password))
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def authenticate_user(db: Session, username: str, password: str):
    hashed = hash_password(password)
    return db.query(User).filter(User.username == username, User.password == hashed).first()


def get_user(db: Session, user_id: int):
    return db.query(User).filter(User.id == user_id).first()

def get_security_advice(topic: str):
    topics = {
        "phishing": "Keep software updated, verify sender domains, and avoid clicking unexpected links.",
        "ransomware": "Maintain regular backups, isolate infected hosts, and use endpoint protection.",
        "compliance": "Document controls, enforce access policies, and review audit logs regularly.",
        "general": "Use strong authentication, monitor traffic, and train users on security awareness.",
    }
    return {
        "topic": topic,
        "advice": topics.get(topic.lower(), topics["general"]),
        "confidence": "medium"
    }

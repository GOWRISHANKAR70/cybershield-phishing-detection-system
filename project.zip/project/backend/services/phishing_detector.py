def analyze_url(url: str) -> dict:
    score = 0
    details = []

    if "https://" not in url:
        score += 30
        details.append("Missing HTTPS protocol")
    if "@" in url:
        score += 30
        details.append("Suspicious @ symbol detected")
    if url.count(".") > 3:
        score += 20
        details.append("Long domain path")
    if url.lower().startswith("http://"):
        score += 20
        details.append("Insecure HTTP protocol")

    risk = "low"
    if score >= 70:
        risk = "high"
    elif score >= 40:
        risk = "medium"

    return {
        "url": url,
        "score": score,
        "risk": risk,
        "details": details or ["Looks normal based on basic heuristics"]
    }

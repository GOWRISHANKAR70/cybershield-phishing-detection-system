import os
import sys
from flask import Flask, jsonify
from flask_cors import CORS

if __package__ is None and __name__ == "__main__":
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend.config import SECRET_KEY
from backend.database import init_db
from backend.routes.auth_routes import auth_bp
from backend.routes.phishing_routes import phishing_bp
from backend.routes.threat_routes import threat_bp
from backend.routes.ai_routes import aI_bp


def create_app():
    app = Flask(__name__)
    app.config["SECRET_KEY"] = SECRET_KEY
    CORS(app, resources={r"/api/*": {"origins": "*"}})

    init_db()
    app.register_blueprint(auth_bp)
    app.register_blueprint(phishing_bp)
    app.register_blueprint(threat_bp)
    app.register_blueprint(aI_bp)

    @app.route("/api/ping")
    def ping():
        return jsonify({"status": "ok", "message": "CyberShield-AI backend is running"})

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(host="127.0.0.1", port=5000, debug=True)

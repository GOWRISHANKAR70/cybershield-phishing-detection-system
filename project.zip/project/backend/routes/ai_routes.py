from flask import Blueprint, request, jsonify
from ..services.ai_security_agent import get_security_advice

aI_bp = Blueprint("ai", __name__, url_prefix="/api/ai")


@aI_bp.route("/advice", methods=["POST"])
def advice():
    data = request.get_json() or {}
    topic = data.get("topic", "general")
    response = get_security_advice(topic)
    return jsonify(response)

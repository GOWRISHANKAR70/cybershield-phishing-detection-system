from flask import Blueprint, jsonify
from ..services.threat_monitor import generate_sample_threats

threat_bp = Blueprint("threats", __name__, url_prefix="/api/threats")


@threat_bp.route("/dashboard", methods=["GET"])
def get_threats():
    # In a real app, this would query the database and filter by user.
    threats = generate_sample_threats(user_id=1)
    return jsonify({"threats": threats})

from flask import Blueprint, request, jsonify
from ..database import SessionLocal
from ..services.auth_service import register_user, authenticate_user

auth_bp = Blueprint("auth", __name__, url_prefix="/api/auth")


@auth_bp.route("/register", methods=["POST"])
def register():
    data = request.get_json() or {}
    username = data.get("username")
    email = data.get("email")
    password = data.get("password")

    if not username or not email or not password:
        return jsonify({"error": "username, email, and password are required"}), 400

    db = SessionLocal()
    user = register_user(db, username=username, email=email, password=password)
    db.close()

    if not user:
        return jsonify({"error": "Username or email already exists"}), 409

    return jsonify({"message": "User registered successfully", "user": {"id": user.id, "username": user.username, "email": user.email}})


@auth_bp.route("/login", methods=["POST"])
def login():
    data = request.get_json() or {}
    username = data.get("username")
    password = data.get("password")

    if not username or not password:
        return jsonify({"error": "username and password are required"}), 400

    db = SessionLocal()
    user = authenticate_user(db, username=username, password=password)
    db.close()

    if not user:
        return jsonify({"error": "Invalid credentials"}), 401

    return jsonify({"message": "Login successful", "user": {"id": user.id, "username": user.username, "email": user.email}})

from flask import Blueprint, request, jsonify
from ..database import SessionLocal
from ..services.phishing_detector import analyze_url
from ..services.threat_monitor import log_threat

phishing_bp = Blueprint("phishing", __name__, url_prefix="/api/phishing")


@phishing_bp.route("/scan", methods=["POST"])
def scan_url():
    data = request.get_json() or {}
    url = data.get("url")
    user_id = data.get("user_id", 0)

    if not url:
        return jsonify({"error": "URL is required"}), 400

    result = analyze_url(url)
    db = SessionLocal()
    log_threat(db, user_id=user_id, threat_type="Phishing Scan", severity=result["risk"].capitalize(), details=f"Scanned {url} with score {result['score']}")
    db.close()

    return jsonify(result)

import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE_FILE = os.path.join(BASE_DIR, "cybershield.db")
SQLALCHEMY_DATABASE_URI = f"sqlite:///{DATABASE_FILE}"
SECRET_KEY = os.environ.get("CYBERSHIELD_SECRET", "change-this-secret")

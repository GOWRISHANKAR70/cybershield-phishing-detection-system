# Incident Summary

## Incident Details

- Incident ID: {{INCIDENT_ID}}
- Reported at: {{REPORTED_AT}}
- Affected system: {{AFFECTED_SYSTEM}}

## Description

{{DESCRIPTION}}

## Impact

- Users affected: {{USERS_AFFECTED}}
- Data impacted: {{DATA_IMPACTED}}
- Operational impact: {{OPERATIONAL_IMPACT}}

## Response Actions

- Containment steps taken
- Investigation actions
- Recovery steps

## Lessons Learned

- Root cause analysis
- Controls to improve
- Follow-up plan

# CyberShield-AI Security Report Template

## Executive Summary

- Date: {{DATE}}
- Analyst: {{ANALYST_NAME}}
- Overview: Brief summary of the current security posture and main findings.

## Threat Summary

- High severity threats: {{HIGH_SEVERITY_COUNT}}
- Medium severity threats: {{MEDIUM_SEVERITY_COUNT}}
- Low severity threats: {{LOW_SEVERITY_COUNT}}

## Key Findings

1. Finding one
2. Finding two
3. Finding three

## Action Items

- Remediate outdated systems
- Review access controls
- Update security training

## Notes

- Additional observations and recommended next steps.

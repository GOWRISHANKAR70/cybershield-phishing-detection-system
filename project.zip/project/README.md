# CyberShield-AI

A minimal CyberShield-AI starter project with a Python backend and static frontend.

## Structure

- `backend/` - Flask backend, SQLite database, modular routes and services
- `frontend/` - Static HTML/CSS/JS client pages
- `reports/` - Starter report templates and export samples
- `requirements.txt` - Python dependencies

## Setup

1. Create a Python virtual environment:

   ```powershell
   python -m venv venv
   .\venv\Scripts\activate
   ```

2. Install dependencies:

   ```powershell
   pip install -r requirements.txt
   ```

3. Run the backend server:

   ```powershell
   python run.py
   ```

4. Open the frontend in a browser:

   - Open `frontend/index.html` directly
   - or serve it from the frontend folder:

     ```powershell
     cd frontend
     python -m http.server 8000
     ```

## Notes

- The backend exposes simple API endpoints under `http://127.0.0.1:5000/api/`
- The frontend pages use `frontend/app.js` to interact with the backend
- `run.py` is the recommended entrypoint for the backend
- If you enter `http://127.0.0.1` without `:5000`, the browser will refuse the connection because the backend listens on port `5000`.

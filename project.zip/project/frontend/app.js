const API_BASE = "http://127.0.0.1:5000/api";

async function postJson(url, data) {
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const json = await response.json().catch(() => ({}));
    if (!response.ok) {
      return { error: json.error || `Backend error ${response.status}` };
    }
    return json;
  } catch (err) {
    return { error: `Unable to reach backend at ${API_BASE}. Start the backend with python run.py and refresh.` };
  }
}

async function fetchJson(url) {
  try {
    const response = await fetch(url);
    const json = await response.json().catch(() => ({}));
    if (!response.ok) {
      return { error: json.error || `Backend error ${response.status}` };
    }
    return json;
  } catch (err) {
    return { error: `Unable to reach backend at ${API_BASE}. Start the backend with python run.py and refresh.` };
  }
}

function showMessage(container, message, error = false) {
  container.innerHTML = `<div class="alert" style="border-color: ${error ? '#f87171' : '#38bdf8'}">${message}</div>`;
}

async function checkBackend() {
  const statusEl = document.getElementById("backend-status");
  if (!statusEl) return;

  statusEl.textContent = "Checking backend...";
  const response = await fetchJson(`${API_BASE}/ping`);

  if (response.error) {
    statusEl.style.color = "#fecaca";
    statusEl.textContent = response.error;
    return;
  }

  statusEl.style.color = "#86efac";
  statusEl.textContent = `Backend is online: ${response.message}`;
}

if (document.getElementById("backend-check")) {
  document.getElementById("backend-check").addEventListener("click", checkBackend);
}

window.addEventListener("load", () => {
  if (document.getElementById("backend-status")) {
    checkBackend();
  }
});

if (document.getElementById("register-form")) {
  const registerForm = document.getElementById("register-form");
  const messageContainer = document.getElementById("register-message");
  registerForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const formData = new FormData(registerForm);
    const body = {
      username: formData.get("username"),
      email: formData.get("email"),
      password: formData.get("password"),
    };

    const result = await postJson(`${API_BASE}/auth/register`, body);
    if (result.error) {
      showMessage(messageContainer, result.error, true);
      return;
    }
    showMessage(messageContainer, `Account created! Sign in now.`);
    registerForm.reset();
  });
}

if (document.getElementById("login-form")) {
  const loginForm = document.getElementById("login-form");
  const messageContainer = document.getElementById("login-message");
  loginForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const formData = new FormData(loginForm);
    const body = {
      username: formData.get("username"),
      password: formData.get("password"),
    };

    const result = await postJson(`${API_BASE}/auth/login`, body);
    if (result.error) {
      showMessage(messageContainer, result.error, true);
      return;
    }
    showMessage(messageContainer, `Welcome! Redirecting...`);
    setTimeout(() => {
      window.location.href = "dashboard.html";
    }, 500);
  });
}

if (document.getElementById("scan-form")) {
  const scanForm = document.getElementById("scan-form");
  const scanResult = document.getElementById("scan-result");
  scanForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const url = document.getElementById("url").value;
    const formData = new FormData(scanForm);
    const body = {
      url: url,
      user_id: 1,
    };
    
    scanResult.innerHTML = `<div class="alert" style="border-color: #38bdf8;"><strong>Analyzing:</strong> ${url}</div>`;
    
    const result = await postJson(`${API_BASE}/phishing/scan`, body);
    
    if (result.error) {
      scanResult.innerHTML = `<div class="alert" style="border-color: #f87171;"><strong>Error:</strong> ${result.error}</div>`;
      return;
    }
    
    const riskColor = result.risk === "high" ? "#ff2d55" : result.risk === "medium" ? "#ffb800" : "#00ff88";
    const scorePercent = result.score + "%";
    
    scanResult.innerHTML = `
      <div class="alert" style="border-color: ${riskColor};">
        <h2 style="margin-top: 0; color: ${riskColor};">URL Analysis Result</h2>
        <p><strong>URL:</strong> ${url}</p>
        <p><strong>Risk Level:</strong> <span style="color: ${riskColor}; font-weight: 700;">${result.risk.toUpperCase()}</span></p>
        <p><strong>Safety Score:</strong> <span style="color: ${riskColor}; font-size: 1.5rem; font-weight: 700;">${scorePercent}</span></p>
        <p><strong>Analysis Details:</strong></p>
        <ul>${result.details.map(d => `<li>${d}</li>`).join("")}</ul>
        <p style="margin-bottom: 0; font-size: 0.875rem; color: #94a3b8;">${result.risk === "high" ? "⚠️ This URL appears to be phishing or malicious. Do not click it." : result.risk === "medium" ? "⚠️ This URL has some suspicious indicators. Be cautious." : "✅ This URL appears to be safe."}</p>
      </div>
    `;
  });
}

if (document.getElementById("threat-list")) {
  window.addEventListener("load", async () => {
    const data = await fetchJson(`${API_BASE}/threats/dashboard`);
    const container = document.getElementById("threat-list");
    if (data.error) {
      container.innerHTML = `<article><h2>Backend unavailable</h2><p>${data.error}</p></article>`;
      return;
    }
    container.innerHTML = data.threats
      .map(
        (item) => `
          <article>
            <h2>${item.threat_type}</h2>
            <p><strong>Severity:</strong> ${item.severity}</p>
            <p>${item.details}</p>
            <p><small>${item.timestamp}</small></p>
          </article>
        `
      )
      .join("");
  });
}

if (document.getElementById("ai-form")) {
  const aiForm = document.getElementById("ai-form");
  const aiResult = document.getElementById("ai-result");
  aiForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const topic = document.getElementById("topic").value;
    const result = await postJson(`${API_BASE}/ai/advice`, { topic });
    aiResult.innerHTML = `
      <div class="alert">
        <strong>Topic:</strong> ${result.topic}<br />
        <strong>Advice:</strong> ${result.advice}
      </div>
    `;
  });
}

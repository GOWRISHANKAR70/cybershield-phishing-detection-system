import React from "react";
import { createRoot } from "react-dom/client";
// Use the full original app (OriginalApp.jsx) to preserve your UI.
import App from "./OriginalApp.jsx";

createRoot(document.getElementById("root")).render(<App />);

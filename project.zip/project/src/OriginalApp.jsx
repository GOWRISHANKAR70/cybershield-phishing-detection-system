import { useState, useEffect, useRef, useCallback } from "react";
import { AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { Shield, AlertTriangle, Wifi, Users, Search, MessageSquare, LayoutDashboard, LogOut, Bell, ChevronRight, Send, Zap, Lock, Eye, Database, Activity, Globe, Terminal, FileText, Filter, Download, RefreshCw, CheckCircle, XCircle, Clock, TrendingUp, Cpu, Radio } from "lucide-react";

const COLORS = {
  bg: "#080b14",
  bgCard: "rgba(13,18,35,0.85)",
  bgPanel: "rgba(8,11,20,0.95)",
  blue: "#00d4ff",
  purple: "#9d4edd",
  green: "#00ff88",
  red: "#ff2d55",
  amber: "#ffb800",
  border: "rgba(0,212,255,0.15)",
  borderHover: "rgba(0,212,255,0.4)",
  text: "#c8d8f0",
  textMuted: "#5a7090",
};

const glassCard = {
  background: COLORS.bgCard,
  border: `1px solid ${COLORS.border}`,
  borderRadius: 16,
  backdropFilter: "blur(20px)",
  WebkitBackdropFilter: "blur(20px)",
};

const neonText = (color = COLORS.blue) => ({
  color,
  textShadow: `0 0 20px ${color}60, 0 0 40px ${color}30`,
});

const glowBorder = (color = COLORS.blue) => ({
  boxShadow: `0 0 20px ${color}20, inset 0 0 20px ${color}05`,
  border: `1px solid ${color}40`,
});

// ─── Threat data ───
const dailyThreats = [
  { day: "Mon", threats: 4, blocked: 12 },
  { day: "Tue", threats: 7, blocked: 18 },
  { day: "Wed", threats: 3, blocked: 9 },
  { day: "Thu", threats: 12, blocked: 25 },
  { day: "Fri", threats: 6, blocked: 15 },
  { day: "Sat", threats: 2, blocked: 7 },
  { day: "Sun", threats: 9, blocked: 20 },
];

const threatTypes = [
  { type: "DDoS", count: 32, color: COLORS.red },
  { type: "SQL Inj", count: 18, color: COLORS.amber },
  { type: "Phishing", count: 45, color: COLORS.purple },
  { type: "XSS", count: 22, color: COLORS.blue },
  { type: "Brute Force", count: 14, color: COLORS.green },
];

const pieData = [
  { name: "Safe", value: 212, color: COLORS.green },
  { name: "Phishing", value: 38, color: COLORS.red },
];

const liveThreats = [
  { id: 1, type: "DDoS Attack", source: "192.168.1.47", severity: "HIGH", time: "2m ago", status: "BLOCKED" },
  { id: 2, type: "SQL Injection", source: "10.0.0.23", severity: "HIGH", time: "5m ago", status: "BLOCKED" },
  { id: 3, type: "XSS Attempt", source: "172.16.0.8", severity: "MED", time: "8m ago", status: "BLOCKED" },
  { id: 4, type: "SSH Brute Force", source: "203.0.113.5", severity: "MED", time: "12m ago", status: "BLOCKED" },
  { id: 5, type: "Port Scan", source: "198.51.100.9", severity: "LOW", time: "18m ago", status: "LOGGED" },
  { id: 6, type: "Malware Download", source: "192.0.2.15", severity: "HIGH", time: "23m ago", status: "BLOCKED" },
  { id: 7, type: "Phishing Email", source: "spam@evil.tk", severity: "MED", time: "31m ago", status: "QUARANTINED" },
  { id: 8, type: "DNS Tunneling", source: "10.10.10.4", severity: "LOW", time: "45m ago", status: "LOGGED" },
];

const recentScans = [
  { url: "https://google.com", result: "SAFE", score: 98, time: "1m ago" },
  { url: "http://paypa1-login.tk", result: "PHISHING", score: 12, time: "4m ago" },
  { url: "https://github.com", result: "SAFE", score: 97, time: "9m ago" },
  { url: "http://secure-bank-verify.ml", result: "PHISHING", score: 8, time: "15m ago" },
  { url: "https://amazon.com", result: "SAFE", score: 95, time: "22m ago" },
];

// ─── Phishing analysis ───
function analyzeUrl(url) {
  const reasons = [];
  let score = 100;
  try {
    const parsed = new URL(url.startsWith("http") ? url : "https://" + url);
    const hostname = parsed.hostname.toLowerCase();
    const path = parsed.pathname.toLowerCase();

    const riskyTLDs = [".tk", ".ml", ".ga", ".cf", ".gq", ".xyz", ".cc", ".info", ".top", ".icu"];
    if (riskyTLDs.some(t => hostname.endsWith(t))) { score -= 35; reasons.push("Risky TLD detected (.tk/.ml/.ga etc.)"); }

    const suspiciousKw = ["paypal", "paypa1", "login", "secure", "bank", "verify", "signin", "account", "update", "confirm"];
    const allText = hostname + path;
    const found = suspiciousKw.filter(k => allText.includes(k));
    if (found.length) { score -= found.length * 12; reasons.push(`Suspicious keywords: ${found.join(", ")}`); }

    if (parsed.protocol === "http:") { score -= 20; reasons.push("Insecure HTTP protocol"); }

    if (url.length > 75) { score -= 10; reasons.push("Unusually long URL"); }

    const parts = hostname.split(".");
    if (parts.length > 4) { score -= 15; reasons.push("Excessive subdomain depth"); }

    const ipPattern = /^(\d{1,3}\.){3}\d{1,3}$/;
    if (ipPattern.test(hostname)) { score -= 25; reasons.push("IP address used instead of domain"); }

    if (!reasons.length) reasons.push("No suspicious patterns detected");
    score = Math.max(0, Math.min(100, score));
    return { classification: score >= 60 ? "SAFE" : "PHISHING", score, reasons };
  } catch {
    return { classification: "INVALID", score: 0, reasons: ["Invalid URL format"] };
  }
}

// ─── AI Chat ───
async function askAI(messages) {
  const systemPrompt = `You are CyberGuard AI, an elite cybersecurity expert assistant. You specialize in:
- Threat analysis and incident response
- Phishing and social engineering detection
- Vulnerability assessment (CVEs, OWASP Top 10)
- Network security and intrusion detection
- Malware analysis and reverse engineering
- Security best practices and compliance (ISO 27001, SOC 2, NIST)

Format responses with clear sections. Use bullet points for lists. Be concise but thorough. 
When discussing threats, always include: Description, Impact, Mitigation steps.
Start your response directly without pleasantries.`;

  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      system: systemPrompt,
      messages,
    }),
  });
  const data = await res.json();
  return data.content?.map(b => b.text || "").join("") || "Unable to get response.";
}

// ─── Styles ───
const styles = `
  @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Space Grotesk', sans-serif; background: #080b14; color: #c8d8f0; }
  ::-webkit-scrollbar { width: 4px; }
  ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: rgba(0,212,255,0.3); border-radius: 2px; }
  @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }
  @keyframes scanLine { 0%{transform:translateY(-100%)} 100%{transform:translateY(400%)} }
  @keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-6px)} }
  @keyframes fadeIn { from{opacity:0;transform:translateY(10px)} to{opacity:1;transform:translateY(0)} }
  @keyframes glowPulse { 0%,100%{box-shadow:0 0 20px rgba(0,212,255,0.2)} 50%{box-shadow:0 0 40px rgba(0,212,255,0.5)} }
  @keyframes spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
  .fadeIn { animation: fadeIn 0.4s ease; }
  .nav-link { display:flex; align-items:center; gap:10px; padding:10px 14px; border-radius:10px; cursor:pointer; transition:all 0.2s; color:#5a7090; font-size:14px; font-weight:500; border:none; background:none; width:100%; text-align:left; }
  .nav-link:hover { background:rgba(0,212,255,0.08); color:#00d4ff; }
  .nav-link.active { background:rgba(0,212,255,0.12); color:#00d4ff; box-shadow:inset 2px 0 0 #00d4ff; }
  .stat-card { padding:20px; border-radius:14px; background:rgba(13,18,35,0.9); border:1px solid rgba(0,212,255,0.12); transition:all 0.3s; }
  .stat-card:hover { border-color:rgba(0,212,255,0.35); transform:translateY(-2px); }
  .btn-primary { background:linear-gradient(135deg,#00d4ff20,#9d4edd20); border:1px solid #00d4ff60; color:#00d4ff; padding:10px 20px; border-radius:10px; cursor:pointer; font-family:inherit; font-size:14px; font-weight:500; transition:all 0.2s; }
  .btn-primary:hover { background:linear-gradient(135deg,#00d4ff30,#9d4edd30); box-shadow:0 0 20px #00d4ff30; }
  .input-field { background:rgba(0,212,255,0.05); border:1px solid rgba(0,212,255,0.2); border-radius:10px; padding:12px 16px; color:#c8d8f0; font-family:inherit; font-size:14px; outline:none; transition:all 0.2s; width:100%; }
  .input-field:focus { border-color:#00d4ff60; box-shadow:0 0 20px #00d4ff15; }
  .input-field::placeholder { color:#3a5070; }
  .badge-high { background:rgba(255,45,85,0.15); color:#ff2d55; border:1px solid rgba(255,45,85,0.3); padding:2px 8px; border-radius:6px; font-size:11px; font-weight:600; letter-spacing:0.5px; }
  .badge-med { background:rgba(255,184,0,0.15); color:#ffb800; border:1px solid rgba(255,184,0,0.3); padding:2px 8px; border-radius:6px; font-size:11px; font-weight:600; }
  .badge-low { background:rgba(0,212,255,0.12); color:#00d4ff; border:1px solid rgba(0,212,255,0.25); padding:2px 8px; border-radius:6px; font-size:11px; font-weight:600; }
  .chat-bubble { padding:14px 18px; border-radius:14px; margin:8px 0; max-width:80%; font-size:14px; line-height:1.6; }
  .chat-bubble.user { background:linear-gradient(135deg,rgba(0,212,255,0.15),rgba(157,78,221,0.15)); border:1px solid rgba(0,212,255,0.25); align-self:flex-end; }
  .chat-bubble.ai { background:rgba(13,18,35,0.9); border:1px solid rgba(0,212,255,0.12); align-self:flex-start; }
  .mono { font-family:'JetBrains Mono',monospace; }
  .progress-bar-bg { background:rgba(255,255,255,0.06); border-radius:4px; height:6px; overflow:hidden; }
  .threat-row { display:grid; grid-template-columns:1fr 140px 80px 80px 100px; gap:12px; align-items:center; padding:12px 16px; border-radius:10px; border:1px solid transparent; transition:all 0.2s; }
  .threat-row:hover { background:rgba(0,212,255,0.04); border-color:rgba(0,212,255,0.12); }
`;

// ─── Components ───

function Sidebar({ page, setPage, user, setUser }) {
  const links = [
    { id: "dashboard", icon: LayoutDashboard, label: "Dashboard" },
    { id: "phishing", icon: Shield, label: "Phishing Scanner" },
    { id: "threats", icon: AlertTriangle, label: "Threat Monitor" },
    { id: "ai", icon: MessageSquare, label: "AI Assistant" },
  ];

  return (
    <div style={{ width: 220, background: COLORS.bgPanel, borderRight: `1px solid ${COLORS.border}`, display: "flex", flexDirection: "column", flexShrink: 0 }}>
      <div style={{ padding: "24px 18px 20px", borderBottom: `1px solid ${COLORS.border}` }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 36, height: 36, borderRadius: 10, background: "linear-gradient(135deg,#00d4ff,#9d4edd)", display: "flex", alignItems: "center", justifyContent: "center", animation: "glowPulse 3s infinite" }}>
            <Shield size={18} color="#fff" />
          </div>
          <div>
            <div style={{ fontSize: 14, fontWeight: 700, color: "#fff", letterSpacing: 0.5 }}>CyberGuard</div>
            <div style={{ fontSize: 10, color: COLORS.textMuted, letterSpacing: 1 }}>AI PLATFORM</div>
          </div>
        </div>
      </div>

      <nav style={{ padding: "16px 10px", flex: 1 }}>
        <div style={{ fontSize: 10, color: COLORS.textMuted, letterSpacing: 1.5, padding: "0 6px", marginBottom: 8 }}>MAIN MENU</div>
        {links.map(({ id, icon: Icon, label }) => (
          <button key={id} className={`nav-link ${page === id ? "active" : ""}`} onClick={() => setPage(id)}>
            <Icon size={16} />
            {label}
          </button>
        ))}
      </nav>

      <div style={{ padding: "16px 18px", borderTop: `1px solid ${COLORS.border}` }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
          <div style={{ width: 32, height: 32, borderRadius: 8, background: "linear-gradient(135deg,#9d4edd,#00d4ff)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 700, color: "#fff" }}>
            {user.name[0].toUpperCase()}
          </div>
          <div>
            <div style={{ fontSize: 13, fontWeight: 600, color: "#fff" }}>{user.name}</div>
            <div style={{ fontSize: 11, color: COLORS.textMuted }}>Analyst</div>
          </div>
        </div>
        <button className="nav-link" onClick={() => setUser(null)} style={{ color: "#ff2d55" }}>
          <LogOut size={14} /> Logout
        </button>
      </div>
    </div>
  );
}

function Navbar({ page, user }) {
  const [time, setTime] = useState(new Date());
  useEffect(() => { const t = setInterval(() => setTime(new Date()), 1000); return () => clearInterval(t); }, []);

  const titles = { dashboard: "Security Dashboard", phishing: "Phishing Scanner", threats: "Threat Monitor", ai: "AI Security Assistant" };

  return (
    <div style={{ height: 60, background: COLORS.bgPanel, borderBottom: `1px solid ${COLORS.border}`, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 24px", flexShrink: 0 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <ChevronRight size={14} color={COLORS.textMuted} />
        <span style={{ fontSize: 16, fontWeight: 600, color: "#fff" }}>{titles[page]}</span>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <div style={{ width: 6, height: 6, borderRadius: "50%", background: COLORS.green, animation: "pulse 2s infinite" }} />
          <span style={{ fontSize: 12, color: COLORS.textMuted, fontFamily: "'JetBrains Mono'" }}>{time.toLocaleTimeString()}</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 6, background: "rgba(0,255,136,0.08)", border: "1px solid rgba(0,255,136,0.2)", borderRadius: 8, padding: "4px 10px" }}>
          <Database size={12} color={COLORS.green} />
          <span style={{ fontSize: 11, color: COLORS.green }}>DB Online</span>
        </div>
        <div style={{ position: "relative", cursor: "pointer" }}>
          <Bell size={18} color={COLORS.textMuted} />
          <div style={{ position: "absolute", top: -3, right: -3, width: 8, height: 8, borderRadius: "50%", background: COLORS.red }} />
        </div>
      </div>
    </div>
  );
}

function StatsCard({ icon: Icon, label, value, sub, color = COLORS.blue, trend }) {
  return (
    <div className="stat-card" style={glowBorder(color + "40")}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14 }}>
        <div style={{ width: 40, height: 40, borderRadius: 10, background: color + "18", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <Icon size={18} color={color} />
        </div>
        {trend && <div style={{ fontSize: 12, color: COLORS.green, display: "flex", alignItems: "center", gap: 3 }}><TrendingUp size={12} />{trend}</div>}
      </div>
      <div style={{ fontSize: 28, fontWeight: 700, color: "#fff", marginBottom: 4 }}>{value}</div>
      <div style={{ fontSize: 12, color: COLORS.textMuted }}>{label}</div>
      {sub && <div style={{ fontSize: 11, color: color, marginTop: 4 }}>{sub}</div>}
    </div>
  );
}

// ─── Pages ───

function Dashboard() {
  return (
    <div className="fadeIn" style={{ padding: 24, overflowY: "auto", flex: 1 }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16, marginBottom: 24 }}>
        <StatsCard icon={Search} label="Total Scans" value="250" sub="This month" color={COLORS.blue} trend="+12%" />
        <StatsCard icon={AlertTriangle} label="Threat Alerts" value="15" sub="Active threats" color={COLORS.red} />
        <StatsCard icon={Users} label="Active Users" value="20" sub="Online now" color={COLORS.purple} trend="+3" />
        <StatsCard icon={Shield} label="Safe Emails" value="212" sub="38 phishing caught" color={COLORS.green} trend="85%" />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 24 }}>
        <div style={{ ...glassCard, padding: 20 }}>
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 14, fontWeight: 600, color: "#fff" }}>Daily Threat Activity</div>
            <div style={{ fontSize: 12, color: COLORS.textMuted }}>Threats detected vs blocked</div>
          </div>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={dailyThreats}>
              <defs>
                <linearGradient id="gBlocked" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={COLORS.blue} stopOpacity={0.3} />
                  <stop offset="95%" stopColor={COLORS.blue} stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gThreats" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={COLORS.red} stopOpacity={0.3} />
                  <stop offset="95%" stopColor={COLORS.red} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="day" tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: "#0d1223", border: "1px solid rgba(0,212,255,0.2)", borderRadius: 8, color: "#fff" }} />
              <Area type="monotone" dataKey="blocked" stroke={COLORS.blue} fill="url(#gBlocked)" strokeWidth={2} name="Blocked" />
              <Area type="monotone" dataKey="threats" stroke={COLORS.red} fill="url(#gThreats)" strokeWidth={2} name="Threats" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div style={{ ...glassCard, padding: 20 }}>
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 14, fontWeight: 600, color: "#fff" }}>Phishing Detection Rate</div>
            <div style={{ fontSize: 12, color: COLORS.textMuted }}>Safe vs Phishing emails (250 total)</div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 24 }}>
            <ResponsiveContainer width={160} height={160}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={45} outerRadius={70} paddingAngle={3} dataKey="value">
                  {pieData.map((e, i) => <Cell key={i} fill={e.color} />)}
                </Pie>
                <Tooltip contentStyle={{ background: "#0d1223", border: "1px solid rgba(0,212,255,0.2)", borderRadius: 8, color: "#fff" }} />
              </PieChart>
            </ResponsiveContainer>
            <div style={{ flex: 1 }}>
              {pieData.map(d => (
                <div key={d.name} style={{ marginBottom: 12 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                      <div style={{ width: 8, height: 8, borderRadius: "50%", background: d.color }} />
                      <span style={{ fontSize: 13, color: COLORS.text }}>{d.name}</span>
                    </div>
                    <span style={{ fontSize: 13, fontWeight: 600, color: "#fff" }}>{d.value}</span>
                  </div>
                  <div className="progress-bar-bg">
                    <div style={{ height: "100%", width: `${(d.value / 250) * 100}%`, background: d.color, borderRadius: 4 }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        <div style={{ ...glassCard, padding: 20 }}>
          <div style={{ fontSize: 14, fontWeight: 600, color: "#fff", marginBottom: 16 }}>Threat Types This Month</div>
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={threatTypes} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" horizontal={false} />
              <XAxis type="number" tick={{ fill: COLORS.textMuted, fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis dataKey="type" type="category" tick={{ fill: COLORS.text, fontSize: 11 }} axisLine={false} tickLine={false} width={70} />
              <Tooltip contentStyle={{ background: "#0d1223", border: "1px solid rgba(0,212,255,0.2)", borderRadius: 8, color: "#fff" }} />
              <Bar dataKey="count" radius={[0, 4, 4, 0]}>
                {threatTypes.map((e, i) => <Cell key={i} fill={e.color} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div style={{ ...glassCard, padding: 20 }}>
          <div style={{ fontSize: 14, fontWeight: 600, color: "#fff", marginBottom: 16 }}>Recent Scans</div>
          {recentScans.map((s, i) => (
            <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 0", borderBottom: i < recentScans.length - 1 ? `1px solid ${COLORS.border}` : "none" }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 12, color: COLORS.text, fontFamily: "'JetBrains Mono'", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: 200 }}>{s.url}</div>
                <div style={{ fontSize: 11, color: COLORS.textMuted }}>{s.time}</div>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: s.result === "SAFE" ? COLORS.green : COLORS.red }}>{s.result}</div>
                <div style={{ width: 40, height: 4, background: "rgba(255,255,255,0.06)", borderRadius: 2, overflow: "hidden" }}>
                  <div style={{ height: "100%", width: `${s.score}%`, background: s.result === "SAFE" ? COLORS.green : COLORS.red, borderRadius: 2 }} />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function PhishingScanner() {
  const [url, setUrl] = useState("");
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState(null);
  const [history, setHistory] = useState(recentScans.slice(0, 4));

  const scan = async () => {
    if (!url.trim()) return;
    setScanning(true);
    setResult(null);
    await new Promise(r => setTimeout(r, 1800));
    const r = analyzeUrl(url);
    setResult(r);
    setHistory(prev => [{ url, result: r.classification, score: r.score, time: "just now" }, ...prev.slice(0, 4)]);
    setScanning(false);
  };

  const scoreColor = result ? (result.score >= 70 ? COLORS.green : result.score >= 40 ? COLORS.amber : COLORS.red) : COLORS.blue;

  return (
    <div className="fadeIn" style={{ padding: 24, overflowY: "auto", flex: 1 }}>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 380px", gap: 20 }}>
        <div>
          <div style={{ ...glassCard, padding: 24, marginBottom: 20 }}>
            <div style={{ fontSize: 16, fontWeight: 600, color: "#fff", marginBottom: 6 }}>URL Analysis Engine</div>
            <div style={{ fontSize: 13, color: COLORS.textMuted, marginBottom: 20 }}>Enter any URL to analyze for phishing indicators</div>
            <div style={{ display: "flex", gap: 10 }}>
              <input className="input-field" style={{ flex: 1 }} value={url} onChange={e => setUrl(e.target.value)} placeholder="https://example.com or http://suspicious-site.tk" onKeyDown={e => e.key === "Enter" && scan()} />
              <button className="btn-primary" onClick={scan} disabled={scanning} style={{ minWidth: 100, opacity: scanning ? 0.7 : 1 }}>
                {scanning ? <><RefreshCw size={14} style={{ animation: "spin 1s linear infinite", display: "inline" }} /> Scanning</> : <><Search size={14} style={{ display: "inline", marginRight: 6 }} />Scan URL</>}
              </button>
            </div>

            <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
              {["https://google.com", "http://paypa1-verify.tk", "https://github.com"].map(u => (
                <button key={u} onClick={() => setUrl(u)} style={{ fontSize: 11, background: "rgba(0,212,255,0.05)", border: "1px solid rgba(0,212,255,0.15)", borderRadius: 6, padding: "4px 10px", color: COLORS.textMuted, cursor: "pointer", fontFamily: "inherit" }}>{u.length > 25 ? u.slice(0, 25) + "…" : u}</button>
              ))}
            </div>
          </div>

          {scanning && (
            <div style={{ ...glassCard, padding: 32, textAlign: "center" }}>
              <div style={{ width: 60, height: 60, borderRadius: "50%", border: `2px solid ${COLORS.blue}`, borderTopColor: "transparent", animation: "spin 1s linear infinite", margin: "0 auto 16px" }} />
              <div style={{ color: COLORS.blue, fontSize: 14 }}>Analyzing URL patterns...</div>
              <div style={{ color: COLORS.textMuted, fontSize: 12, marginTop: 6 }}>Checking TLD, keywords, protocol, structure</div>
            </div>
          )}

          {result && !scanning && (
            <div className="fadeIn" style={{ ...glassCard, padding: 24, ...glowBorder(scoreColor) }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 }}>
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
                    {result.classification === "SAFE" ? <CheckCircle size={22} color={COLORS.green} /> : result.classification === "PHISHING" ? <XCircle size={22} color={COLORS.red} /> : <AlertTriangle size={22} color={COLORS.amber} />}
                    <span style={{ fontSize: 22, fontWeight: 700, color: scoreColor }}>{result.classification}</span>
                  </div>
                  <div style={{ fontSize: 12, color: COLORS.textMuted, fontFamily: "'JetBrains Mono'", maxWidth: 320, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{url}</div>
                </div>
                <div style={{ textAlign: "center" }}>
                  <div style={{ fontSize: 40, fontWeight: 700, color: scoreColor, ...neonText(scoreColor) }}>{result.score}</div>
                  <div style={{ fontSize: 11, color: COLORS.textMuted }}>Safety Score</div>
                </div>
              </div>

              <div style={{ marginBottom: 12 }}>
                <div className="progress-bar-bg" style={{ height: 8 }}>
                  <div style={{ height: "100%", width: `${result.score}%`, background: `linear-gradient(90deg,${COLORS.red},${COLORS.amber},${COLORS.green})`, backgroundSize: "100% 100%", backgroundPosition: `${result.score}% 0`, borderRadius: 4 }} />
                </div>
              </div>

              <div style={{ fontSize: 13, fontWeight: 600, color: "#fff", marginBottom: 10 }}>Analysis Findings:</div>
              {result.reasons.map((r, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", gap: 8, padding: "6px 0", borderBottom: `1px solid ${COLORS.border}` }}>
                  <div style={{ width: 6, height: 6, borderRadius: "50%", background: r.includes("detected") || r.includes("Insecure") || r.includes("suspicious") || r.includes("Excessive") || r.includes("IP") ? COLORS.red : COLORS.green, flexShrink: 0 }} />
                  <span style={{ fontSize: 13, color: COLORS.text }}>{r}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div style={{ ...glassCard, padding: 20, alignSelf: "start" }}>
          <div style={{ fontSize: 14, fontWeight: 600, color: "#fff", marginBottom: 16 }}>Scan History</div>
          {history.map((s, i) => (
            <div key={i} style={{ display: "flex", gap: 10, alignItems: "center", padding: "10px 0", borderBottom: i < history.length - 1 ? `1px solid ${COLORS.border}` : "none" }}>
              {s.result === "SAFE" ? <CheckCircle size={14} color={COLORS.green} /> : <XCircle size={14} color={COLORS.red} />}
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 11, color: COLORS.text, fontFamily: "'JetBrains Mono'", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{s.url}</div>
                <div style={{ fontSize: 10, color: COLORS.textMuted }}>{s.time}</div>
              </div>
              <div style={{ fontSize: 11, fontWeight: 600, color: s.result === "SAFE" ? COLORS.green : COLORS.red }}>{s.score}%</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function ThreatMonitor() {
  const [filter, setFilter] = useState("ALL");
  const [search, setSearch] = useState("");
  const [threats, setThreats] = useState(liveThreats);

  const filtered = threats.filter(t => {
    const matchFilter = filter === "ALL" || t.severity === filter;
    const matchSearch = !search || t.type.toLowerCase().includes(search.toLowerCase()) || t.source.toLowerCase().includes(search.toLowerCase());
    return matchFilter && matchSearch;
  });

  useEffect(() => {
    const newTypes = ["Port Scan", "DDoS Spike", "Credential Stuffing", "CSRF Attempt"];
    const sources = ["10.0.0." + Math.floor(Math.random() * 255), "192.168.1." + Math.floor(Math.random() * 255)];
    const sevs = ["HIGH", "MED", "LOW"];
    const interval = setInterval(() => {
      const newThreat = {
        id: Date.now(),
        type: newTypes[Math.floor(Math.random() * newTypes.length)],
        source: sources[Math.floor(Math.random() * sources.length)],
        severity: sevs[Math.floor(Math.random() * sevs.length)],
        time: "just now",
        status: "BLOCKED",
      };
      setThreats(prev => [newThreat, ...prev.slice(0, 19)]);
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fadeIn" style={{ padding: 24, overflowY: "auto", flex: 1 }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 16, marginBottom: 20 }}>
        <StatsCard icon={AlertTriangle} label="High Severity" value={threats.filter(t => t.severity === "HIGH").length} color={COLORS.red} />
        <StatsCard icon={Activity} label="Medium Severity" value={threats.filter(t => t.severity === "MED").length} color={COLORS.amber} />
        <StatsCard icon={Radio} label="Low Severity" value={threats.filter(t => t.severity === "LOW").length} color={COLORS.blue} />
      </div>

      <div style={{ ...glassCard, padding: 20 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <div style={{ width: 8, height: 8, borderRadius: "50%", background: COLORS.green, animation: "pulse 1.5s infinite" }} />
            <span style={{ fontSize: 14, fontWeight: 600, color: "#fff" }}>Live Threat Feed</span>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <input className="input-field" style={{ width: 180, padding: "7px 12px" }} placeholder="Search threats..." value={search} onChange={e => setSearch(e.target.value)} />
            {['ALL', 'HIGH', 'MED', 'LOW'].map(f => (
              <button key={f} onClick={() => setFilter(f)} style={{ padding: "6px 12px", borderRadius: 8, border: `1px solid ${filter === f ? COLORS.blue + "60" : COLORS.border}`, background: filter === f ? COLORS.blue + "15" : "transparent", color: filter === f ? COLORS.blue : COLORS.textMuted, cursor: "pointer", fontSize: 12, fontFamily: "inherit" }}>{f}</button>
            ))}
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 140px 80px 80px 100px", gap: 12, padding: "8px 16px", marginBottom: 4 }}>
          {['Threat Type', 'Source IP', 'Severity', 'Time', 'Status'].map(h => (
            <div key={h} style={{ fontSize: 11, color: COLORS.textMuted, letterSpacing: 0.5 }}>{h}</div>
          ))}
        </div>

        {filtered.map(t => (
          <div key={t.id} className="threat-row">
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <AlertTriangle size={13} color={t.severity === "HIGH" ? COLORS.red : t.severity === "MED" ? COLORS.amber : COLORS.blue} />
              <span style={{ fontSize: 13, color: COLORS.text }}>{t.type}</span>
            </div>
            <span className="mono" style={{ fontSize: 12, color: COLORS.textMuted }}>{t.source}</span>
            <span className={`badge-${t.severity.toLowerCase()}`}>{t.severity}</span>
            <span style={{ fontSize: 12, color: COLORS.textMuted }}>{t.time}</span>
            <span style={{ fontSize: 11, fontWeight: 600, color: t.status === "BLOCKED" ? COLORS.green : t.status === "QUARANTINED" ? COLORS.amber : COLORS.textMuted }}>{t.status}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function AIChatbot() {
  const [messages, setMessages] = useState([
    { role: "assistant", content: "**CyberGuard AI online.** I'm your dedicated cybersecurity expert. Ask me about threats, vulnerabilities, phishing, malware analysis, or any security topic. How can I help secure your environment today?" }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef();

  const quickPrompts = [
    "Explain SQL Injection attacks",
    "How to detect phishing emails?",
    "What is a DDoS attack?",
    "OWASP Top 10 vulnerabilities",
  ];

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const send = useCallback(async (text) => {
    const msg = text || input.trim();
    if (!msg || loading) return;
    setInput("");
    const userMsg = { role: "user", content: msg };
    setMessages(prev => [...prev, userMsg]);
    setLoading(true);
    try {
      const history = [...messages, userMsg].map(m => ({ role: m.role, content: m.content }));
      const reply = await askAI(history);
      setMessages(prev => [...prev, { role: "assistant", content: reply }]);
    } catch {
      setMessages(prev => [...prev, { role: "assistant", content: "Connection error. Please check your network and try again." }]);
    }
    setLoading(false);
  }, [input, messages, loading]);

  const formatMessage = (content) => {
    return content
      .replace(/\*\*(.*?)\*\*/g, `<strong style="color:#fff">$1</strong>`)
      .replace(/`(.*?)`/g, `<code style="background:rgba(0,212,255,0.1);color:#00d4ff;padding:1px 6px;border-radius:4px;font-family:'JetBrains Mono';font-size:12px">$1</code>`)
      .replace(/\n/g, "<br/>");
  };

  return (
    <div className="fadeIn" style={{ display: "flex", flexDirection: "column", flex: 1, padding: 24, overflow: "hidden" }}>
      <div style={{ display: "flex", gap: 8, marginBottom: 16, flexWrap: "wrap" }}>
        {quickPrompts.map(p => (
          <button key={p} onClick={() => send(p)} style={{ fontSize: 12, background: "rgba(157,78,221,0.08)", border: "1px solid rgba(157,78,221,0.25)", borderRadius: 20, padding: "5px 12px", color: COLORS.purple, cursor: "pointer", fontFamily: "inherit", transition: "all 0.2s" }}>
            {p}
          </button>
        ))}
      </div>

      <div style={{ flex: 1, overflowY: "auto", display: "flex", flexDirection: "column", gap: 4, marginBottom: 16 }}>
        {messages.map((m, i) => (
          <div key={i} style={{ display: "flex", justifyContent: m.role === "user" ? "flex-end" : "flex-start" }}>
            {m.role === "assistant" && (
              <div style={{ width: 28, height: 28, borderRadius: 8, background: "linear-gradient(135deg,#00d4ff,#9d4edd)", display: "flex", alignItems: "center", justifyContent: "center", marginRight: 8, flexShrink: 0, marginTop: 4 }}>
                <Cpu size={13} color="#fff" />
              </div>
            )}
            <div className={`chat-bubble ${m.role}`} dangerouslySetInnerHTML={{ __html: formatMessage(m.content) }} />
          </div>
        ))}
        {loading && (
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <div style={{ width: 28, height: 28, borderRadius: 8, background: "linear-gradient(135deg,#00d4ff,#9d4edd)", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Cpu size={13} color="#fff" />
            </div>
            <div className="chat-bubble ai" style={{ display: "flex", gap: 5, alignItems: "center" }}>
              {[0, 1, 2].map(d => <div key={d} style={{ width: 6, height: 6, borderRadius: "50%", background: COLORS.blue, animation: `pulse 1.2s ${d * 0.2}s infinite` }} />)}
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      <div style={{ ...glassCard, padding: "10px 12px", display: "flex", gap: 10, alignItems: "center" }}>
        <Terminal size={16} color={COLORS.textMuted} />
        <input className="input-field" style={{ flex: 1, border: "none", background: "transparent", padding: "6px 0" }} value={input} onChange={e => setInput(e.target.value)} placeholder="Ask about any cybersecurity topic..." onKeyDown={e => e.key === "Enter" && !e.shiftKey && send()} />
        <button onClick={() => send()} disabled={loading || !input.trim()} style={{ width: 36, height: 36, borderRadius: 8, background: loading || !input.trim() ? "rgba(0,212,255,0.05)" : "linear-gradient(135deg,#00d4ff,#9d4edd)", border: "none", cursor: loading || !input.trim() ? "not-allowed" : "pointer", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
          <Send size={15} color={loading || !input.trim() ? COLORS.textMuted : "#fff"} />
        </button>
      </div>
    </div>
  );
}

function LoginPage({ onLogin }) {
  const [form, setForm] = useState({ email: "", password: "" });
  const [err, setErr] = useState("");

  const submit = () => {
    if (!form.email || !form.password) { setErr("Please fill all fields."); return; }
    if (form.password.length < 6) { setErr("Password must be at least 6 characters."); return; }
    onLogin({ name: form.email.split("@")[0] || "analyst", email: form.email });
  };

  return (
    <div style={{ minHeight: "100vh", background: COLORS.bg, display: "flex", alignItems: "center", justifyContent: "center", position: "relative", overflow: "hidden" }}>
      <div style={{ position: "absolute", inset: 0, background: "radial-gradient(circle at 30% 50%, rgba(0,212,255,0.05) 0%, transparent 60%), radial-gradient(circle at 70% 50%, rgba(157,78,221,0.05) 0%, transparent 60%)" }} />
      {[...Array(6)].map((_, i) => (
        <div key={i} style={{ position: "absolute", width: 1, background: `linear-gradient(180deg,transparent,rgba(0,212,255,${0.05 + i * 0.01}),transparent)`, height: "100%", left: `${10 + i * 16}%`, top: 0 }} />
      ))}

      <div style={{ ...glassCard, padding: 48, width: 420, position: "relative", ...glowBorder() }}>
        <div style={{ textAlign: "center", marginBottom: 36 }}>
          <div style={{ width: 72, height: 72, borderRadius: 20, background: "linear-gradient(135deg,#00d4ff20,#9d4edd20)", border: "1px solid rgba(0,212,255,0.3)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px", animation: "glowPulse 3s infinite" }}>
            <Shield size={36} color={COLORS.blue} />
          </div>
          <div style={{ fontSize: 24, fontWeight: 700, color: "#fff", marginBottom: 4 }}>CyberGuard AI</div>
          <div style={{ fontSize: 13, color: COLORS.textMuted }}>Security Intelligence Platform</div>
        </div>

        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 12, color: COLORS.textMuted, marginBottom: 6 }}>Email Address</div>
          <input className="input-field" type="email" placeholder="analyst@company.com" value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))} />
        </div>
        <div style={{ marginBottom: 20 }}>
          <div style={{ fontSize: 12, color: COLORS.textMuted, marginBottom: 6 }}>Password</div>
          <input className="input-field" type="password" placeholder="••••••••" value={form.password} onChange={e => setForm(p => ({ ...p, password: e.target.value }))} onKeyDown={e => e.key === "Enter" && submit()} />
        </div>

        {err && <div style={{ fontSize: 12, color: COLORS.red, marginBottom: 12, padding: "8px 12px", background: "rgba(255,45,85,0.08)", borderRadius: 8, border: "1px solid rgba(255,45,85,0.2)" }}>{err}</div>}

        <button className="btn-primary" onClick={submit} style={{ width: "100%", padding: 14, fontSize: 15, fontWeight: 600 }}>
          <Lock size={14} style={{ display: "inline", marginRight: 8 }} />Secure Login
        </button>

        <div style={{ marginTop: 16, textAlign: "center", fontSize: 12, color: COLORS.textMuted }}>
          Protected by CyberGuard AI • All sessions encrypted
        </div>
      </div>
    </div>
  );
}

// ─── Root App ───
export default function App() {
  const [user, setUser] = useState(null);
  const [page, setPage] = useState("dashboard");

  if (!user) return (
    <>
      <style>{styles}</style>
      <LoginPage onLogin={setUser} />
    </>
  );

  const PageMap = { dashboard: Dashboard, phishing: PhishingScanner, threats: ThreatMonitor, ai: AIChatbot };
  const PageComponent = PageMap[page];

  return (
    <>
      <style>{styles}</style>
      <div style={{ display: "flex", height: "100vh", background: COLORS.bg, overflow: "hidden" }}>
        <Sidebar page={page} setPage={setPage} user={user} setUser={setUser} />
        <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
          <Navbar page={page} user={user} />
          <PageComponent />
        </div>
      </div>
    </>
  );
}

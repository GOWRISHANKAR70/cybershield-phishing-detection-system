import React, { useState } from "react";

const styles = `
  body { font-family: Arial, Helvetica, sans-serif; background: #080b14; color: #c8d8f0; }
  .container { max-width: 900px; margin: 36px auto; padding: 20px; }
  .card { background: rgba(13,18,35,0.9); padding: 18px; border-radius: 12px; border: 1px solid rgba(0,212,255,0.08); }
  .input { width: 100%; padding: 10px 12px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.06); background: rgba(0,0,0,0.2); color: #c8d8f0; }
  .btn { margin-top: 8px; padding: 10px 14px; border-radius: 8px; background: linear-gradient(135deg,#00d4ff,#9d4edd); color: #001; border: none; cursor: pointer; }
  .reason { margin: 6px 0; padding: 8px; background: rgba(255,255,255,0.02); border-radius: 6px; }
`;

function analyzeUrl(url) {
    const reasons = [];
    let score = 100;
    try {
        const parsed = new URL(url.startsWith("http") ? url : "https://" + url);
        const hostname = parsed.hostname.toLowerCase();
        const path = parsed.pathname.toLowerCase();

        const riskyTLDs = [".tk", ".ml", ".ga", ".cf", ".gq", ".xyz", ".cc", ".info", ".top", ".icu"];
        if (riskyTLDs.some(t => hostname.endsWith(t))) { score -= 35; reasons.push("Risky TLD detected (.tk/.ml/.ga etc.)"); }

        const suspiciousKw = ["paypal", "paypa1", "login", "secure", "bank", "verify", "signin", "account", "update", "confirm"];
        const allText = hostname + path;
        const found = suspiciousKw.filter(k => allText.includes(k));
        if (found.length) { score -= found.length * 12; reasons.push(`Suspicious keywords: ${found.join(", ")}`); }

        if (parsed.protocol === "http:") { score -= 20; reasons.push("Insecure HTTP protocol"); }

        if (url.length > 75) { score -= 10; reasons.push("Unusually long URL"); }

        const parts = hostname.split('.');
        if (parts.length > 4) { score -= 15; reasons.push("Excessive subdomain depth"); }

        const ipPattern = /^(\d{1,3}\.){3}\d{1,3}$/;
        if (ipPattern.test(hostname)) { score -= 25; reasons.push("IP address used instead of domain"); }

        if (!reasons.length) reasons.push("No suspicious patterns detected");
        score = Math.max(0, Math.min(100, score));
        return { classification: score >= 60 ? "SAFE" : "PHISHING", score, reasons };
    } catch {
        return { classification: "INVALID", score: 0, reasons: ["Invalid URL format"] };
    }
}

export default function App() {
    const [url, setUrl] = useState("");
    const [result, setResult] = useState(null);

    const scan = () => {
        const r = analyzeUrl(url);
        setResult(r);
    };

    return (
        <div className="container">
            <style>{styles}</style>
            <h1>CyberGuard — URL Scanner (Demo)</h1>
            <div className="card">
                <label>URL to analyze</label>
                <input className="input" value={url} onChange={e => setUrl(e.target.value)} placeholder="https://example.com or suspicious-site.tk" />
                <div style={{ display: 'flex', gap: 8 }}>
                    <button className="btn" onClick={scan}>Scan</button>
                    <button className="btn" onClick={() => { setUrl('http://paypa1-login.tk'); setResult(null); }}>Load Example</button>
                </div>
            </div>

            {result && (
                <div style={{ marginTop: 18 }} className="card">
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <div>
                            <strong>{result.classification}</strong>
                            <div style={{ color: '#9fb0d0' }}>{url}</div>
                        </div>
                        <div style={{ fontSize: 32, fontWeight: 700, color: result.classification === 'SAFE' ? '#00ff88' : '#ff2d55' }}>{result.score}</div>
                    </div>

                    <div style={{ marginTop: 12 }}>
                        <div style={{ fontWeight: 600 }}>Findings</div>
                        {result.reasons.map((r, i) => <div className="reason" key={i}>{r}</div>)}
                    </div>
                </div>
            )}
        </div>
    );
}
